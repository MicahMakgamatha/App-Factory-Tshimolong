//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "Unit2.h"
#include "Unit1.h"
#include "Unit2.cpp"
#include "Unit1.cpp"

#include <iostream>
#include <String>
#include <conio.h>
#include <fstream>
#include <windows.h>
#include <ctime>
#include "Unit3.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm3 *Form3;
//---------------------------------------------------------------------------
__fastcall TForm3::TForm3(TComponent* Owner)
	: TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TForm3::Button1Click(TObject *Sender)
{
	 int oldest=0;
	   int youngest=0;

		Form1->Show();
		Form2->Hide();
		Form3->Hide();

	   NoOfSur->Caption= IntToStr(NumberSurvey);
	   AvgAge->Caption= IntToStr(TAge/NumberSurvey);

	   if (Age>oldest)
	   {
		   oldest=Age;
	   }

	   oldestAge->Caption= IntToStr(oldest);

		if (Age<youngest)
	   {
		   youngest=Age;
	   }

	   YoungestAge->Caption= IntToStr(youngest);

	  //food number

	  PercPizza->Caption= IntToStr((Pizza/NumberSurvey)*100);
	  PercPasta->Caption= IntToStr((Pasta/NumberSurvey)*100);
	  PercPW->Caption= IntToStr((PW/NumberSurvey)*100);

	  TotalEatOut->Caption=IntToStr(TEatOut);
	  TotalMovies->Caption=IntToStr(TwatchM);
	  TotalTV->Caption=IntToStr(TwatchTV);
	  TotalRadio->Caption=IntToStr(TLRadio);



}
//---------------------------------------------------------------------------



