//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "Unit1.h"
#include <iostream>
#include <string>
#include <conio.h>
#include <fstream>
#include <windows.h>

#include "Unit2.h"
#include "Unit3.h"



using namespace std;

//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm1 *Form1;

//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
	: TForm(Owner)
{
	Button1->Caption="Fill out Survey";
	Button2->Caption="View Survey Results";
	//Form1->Show();
	//Form2->Hide();
	//Form3->Show();


	//Form2->hide;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Button1Click(TObject *Sender)
{
	Form1->Hide();
	Form2->Show();
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Button2Click(TObject *Sender)
{



	Form1->Hide();
	Form2->Hide();
	Form3->Show();

}
//---------------------------------------------------------------------------

