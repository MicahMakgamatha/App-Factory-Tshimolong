//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "Unit3.h"
#include "Unit2.h"
#include "Unit1.h"

#include <iostream>
#include <String>
#include <conio.h>
#include <fstream>
#include <windows.h>
#include <ctime>

//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm2 *Form2;
int NumberSurvey;
 int TEatOut,TwatchM,TwatchTV,TLRadio;
 String Surname,Name;
 int Age=0,PNumber;
 int TAge;
 TDateTime dt;
 int Pizza=0,Pasta=0,PW=0,Chicken=0,beef=0,other=0;

 //functions

 void PrintAge()
 {
	MessageDlg("Age may not be less than 5 and larger than 150, Try again", mtError, TMsgDlgButtons()<<mbOK, 0);
 }

 void approved()
 {
	ShowMessage("Information Approved");
 }




//---------------------------------------------------------------------------
__fastcall TForm2::TForm2(TComponent* Owner)
	: TForm(Owner)
{
}
//---------------------------------------------------------------------------


void __fastcall TForm2::FormCreate(TObject *Sender)
{
   Memo1->Clear();
   Memo2->Clear();
   Memo3->Clear();
  // Memo4->Clear();
   Memo5->Clear();

}
//---------------------------------------------------------------------------

void __fastcall TForm2::submitBtnClick(TObject *Sender)
{




		Surname= Memo1->Text;
		Name= Memo2->Text;
		PNumber= StrToInt(Memo3->Text);
		dt=DateTimePicker1->Date;
		Age= StrToInt(Memo5->Text);


		 if (Age<5||Age>150)
		  {
			PrintAge();
		  }
		  else
		  {
             approved();
			 ListBox1->Items->Add(Surname+" "+Name+" "+PNumber+" "+dt+" "+Age);
		  }

		   TAge=Age;
		  NumberSurvey=(ListBox1->Count);
		  Label10->Caption=("No Sur:"+ IntToStr(NumberSurvey));




			if (RadioGroup1->ItemIndex==0||RadioGroup1->ItemIndex==1)
		  {
			   int EatOut;
			   EatOut++  ;
			   TEatOut=EatOut;
		  }


		  if (RadioGroup2->ItemIndex==0||RadioGroup2->ItemIndex==1)
		  {
			  int watchM;
			  watchM++  ;
			  TwatchM=watchM;
		  }


		   if (RadioGroup3->ItemIndex==0||RadioGroup3->ItemIndex==1)
		  {
			  int watchTV;
			  watchTV++  ;
			  TwatchTV=watchTV;
		  }


		   if (RadioGroup4->ItemIndex==0||RadioGroup4->ItemIndex==1)
		  {
			  int LRadio;
			  LRadio++  ;
              TLRadio=LRadio;
		  }





		if (CheckBox1->Checked)
		{
			//int Pizza=0 ;
			Pizza++;
		}

			if (CheckBox2->Checked)
		{
				Pasta++;
		}

			if (CheckBox3->Checked)
		{

			PW++;
		}

			if (CheckBox4->Checked)
		{
		   //	int Chicken=0 ;
			Chicken++;
		}

			if (CheckBox5->Checked)
		{

			beef++;
		}

			if (CheckBox6->Checked)
		{

			other++;
		}

			Form1->Show();
			ShowMessage("Information Saved and processed");



}
//---------------------------------------------------------------------------

